//
//  TodoList.swift
//  FeelFurther
//
//  Created by scholar on 8/15/23.
//

import SwiftUI

struct TodoList: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TodoList_Previews: PreviewProvider {
    static var previews: some View {
        TodoList()
    }
}
